package ArrayChallenge;

public class MatrixMultiplier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
